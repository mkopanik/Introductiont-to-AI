from utils.control import run_with_controller
from park import PerpParkController, ParaParkController


if __name__ == '__main__':
    #run_with_controller(PerpParkController)
    run_with_controller(ParaParkController)
